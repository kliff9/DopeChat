'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'broom-ball';
var width = 640;
var height = 512;
var aliases = ["quidditch","quidditch-broom-ball"];
var unicode = 'f458';
var svgPathData = 'M633.3 12.4c10.8 14 8.3 34.1-5.6 44.9l-144 112-72 56L403 232l28.3 36.3c3.7 4.8 4.4 11.2 1.8 16.7s-8.1 9-14.1 9.1l-48 .9L292.3 194.2l12.5-46.3c1.6-5.9 6.3-10.3 12.3-11.5s12 1.1 15.8 5.8l30.8 39.4 8.7-6.8 72-56 144-112c13.9-10.9 34.1-8.3 44.9 5.6zM269.1 476.3c-55.5 43.4-215 34.2-252.3 31.4c-5.1-.4-9.7-2.9-12.8-7s-4.5-9.1-3.6-14.1c.5-3.2 1.3-7.2 2.2-12.1c3-16.5 10.8-31.6 21.9-44.1l73.5-82.5c3.1-3.5 3.2-8.6 .4-12.3s-7.9-4.7-12-2.6L47.3 353.5c-6.3 3.3-13.4-2.7-11-9.4c14.3-39.9 32.7-76.9 55.5-94.7c57.7-45.1 175.3-35.5 175.3-35.5l78.8 100.9s-19.1 116.4-76.8 161.5zM496 512c-44.2 0-80-35.8-80-80s35.8-80 80-80s80 35.8 80 80s-35.8 80-80 80z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBroomBall = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;